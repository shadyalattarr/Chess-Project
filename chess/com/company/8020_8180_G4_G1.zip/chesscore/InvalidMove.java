package com.company.chesscore;

public class InvalidMove extends IllegalArgumentException {
    
}
