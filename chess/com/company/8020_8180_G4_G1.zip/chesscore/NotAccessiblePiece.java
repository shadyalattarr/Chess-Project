package com.company.chesscore;
public class NotAccessiblePiece extends IllegalArgumentException {
        
}
