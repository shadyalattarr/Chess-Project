package ChessCore;

public interface GameStateObserver {
    void update(GameStatus status);
}
