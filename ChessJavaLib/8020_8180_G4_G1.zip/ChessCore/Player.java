package ChessCore;

public enum Player {
    WHITE,
    BLACK,
}
